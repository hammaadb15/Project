import type { SeizureRecord, FilterState, TopTenEntry, HeatPoint } from '../types'
import { getPresetRange } from './dateUtils'

export function applyFilters(records: SeizureRecord[], filters: FilterState): SeizureRecord[] {
  let result = [...records]

  // Date filter
  if (filters.datePreset !== 'all') {
    let start = filters.dateStart
    let end   = filters.dateEnd

    if (filters.datePreset !== 'custom') {
      const range = getPresetRange(filters.datePreset)
      start = range.start
      end   = range.end
    }
    if (start) result = result.filter((r) => r.date >= start)
    if (end)   result = result.filter((r) => r.date <= end)
  }

  // Category filter
  if (filters.categories.length > 0) {
    result = result.filter((r) => filters.categories.includes(r.category))
  }

  // Sub-category filter
  if (filters.subCategories.length > 0) {
    result = result.filter((r) => filters.subCategories.includes(r.subCategory))
  }

  // Postcode filter
  if (filters.postcode.trim()) {
    const pc = filters.postcode.trim().toLowerCase()
    result = result.filter((r) => r.postcode.toLowerCase().startsWith(pc))
  }

  // City filter
  if (filters.city.trim()) {
    const city = filters.city.trim().toLowerCase()
    result = result.filter((r) => r.city.toLowerCase().includes(city))
  }

  // Keyword search — scans all string values
  if (filters.keyword.trim()) {
    const kw = filters.keyword.trim().toLowerCase()
    result = result.filter((r) =>
      Object.values(r).some((v) => String(v).toLowerCase().includes(kw))
    )
  }

  return result
}

export function getTopTen(records: SeizureRecord[]): TopTenEntry[] {
  const counts: Record<string, number> = {}
  for (const r of records) {
    counts[r.item] = (counts[r.item] ?? 0) + r.quantity
  }
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, value]) => ({ name, value }))
}

export function getHeatPoints(records: SeizureRecord[]): HeatPoint[] {
  const map: Record<string, HeatPoint> = {}
  for (const r of records) {
    if (r.lat == null || r.lng == null) continue
    const key = r.postcode
    if (!map[key]) {
      map[key] = { postcode: r.postcode, city: r.city, lat: r.lat, lng: r.lng, count: 0 }
    }
    map[key].count += r.quantity
  }
  return Object.values(map)
}

export function getUniqueValues<K extends keyof SeizureRecord>(
  records: SeizureRecord[],
  key: K
): string[] {
  return [...new Set(records.map((r) => String(r[key])))].filter(Boolean).sort()
}

export function getCategoryBreakdown(records: SeizureRecord[]) {
  const counts: Record<string, number> = {}
  for (const r of records) {
    counts[r.category] = (counts[r.category] ?? 0) + r.quantity
  }
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([name, value]) => ({ name, value }))
}
