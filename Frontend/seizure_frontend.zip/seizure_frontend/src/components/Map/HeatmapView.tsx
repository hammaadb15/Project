import { useMemo } from 'react'
import { MapContainer, TileLayer, CircleMarker, Tooltip } from 'react-leaflet'
import { AlertTriangle } from 'lucide-react'
import { getHeatPoints } from '../../utils/dataTransform'
import type { SeizureRecord } from '../../types'

interface Props {
  records: SeizureRecord[]
}

function getColor(value: number, min: number, max: number): string {
  if (max === min) return '#3b82f6'
  const t = (value - min) / (max - min)
  // Blue (low) → Yellow (mid) → Red (high)
  if (t < 0.5) {
    const r = Math.round(59  + (250 - 59)  * (t * 2))
    const g = Math.round(130 + (204 - 130) * (t * 2))
    const b = Math.round(246 + (0   - 246) * (t * 2))
    return `rgb(${r},${g},${b})`
  } else {
    const tt = (t - 0.5) * 2
    const r  = Math.round(250 + (239 - 250) * tt)
    const g  = Math.round(204 + (68  - 204) * tt)
    const b  = Math.round(0)
    return `rgb(${r},${g},${b})`
  }
}

export default function HeatmapView({ records }: Props) {
  const points = useMemo(() => getHeatPoints(records), [records])

  const counts = points.map((p) => p.count)
  const min    = Math.min(...counts, 0)
  const max    = Math.max(...counts, 1)

  const showWarning = records.length < 10

  return (
    <div className="flex flex-col gap-3 h-full">
      {showWarning && (
        <div
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm"
          style={{ background: '#fffbeb', color: '#92400e', border: '1px solid #fde68a' }}
        >
          <AlertTriangle size={15} />
          <span>
            <strong>Note:</strong> Fewer than 10 records are visible. Results may not be statistically representative.
          </span>
        </div>
      )}

      <div className="flex-1 rounded-xl overflow-hidden border border-slate-200" style={{ minHeight: 480 }}>
        <MapContainer
          center={[54.5, -2.5]}
          zoom={6}
          style={{ height: '100%', width: '100%', minHeight: 480 }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {points.map((pt) => (
            <CircleMarker
              key={pt.postcode}
              center={[pt.lat, pt.lng]}
              radius={Math.max(6, Math.min(30, 6 + (pt.count / max) * 24))}
              pathOptions={{
                fillColor:   getColor(pt.count, min, max),
                fillOpacity: 0.75,
                color:       '#fff',
                weight:      1,
              }}
            >
              <Tooltip>
                <div className="text-xs">
                  <strong>{pt.postcode}</strong> — {pt.city}<br />
                  Total quantity: <strong>{pt.count.toLocaleString()}</strong>
                </div>
              </Tooltip>
            </CircleMarker>
          ))}
        </MapContainer>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3">
        <span className="text-xs text-slate-500">Low</span>
        <div
          className="h-3 flex-1 rounded-full"
          style={{
            background:
              'linear-gradient(to right, rgb(59,130,246), rgb(250,204,0), rgb(239,68,68))',
          }}
        />
        <span className="text-xs text-slate-500">High</span>
      </div>

      {points.length === 0 && (
        <p className="text-sm text-slate-400 text-center py-4">
          No geocoded records to display. Ensure your data includes postcodes.
        </p>
      )}
    </div>
  )
}
