import type { SeizureRecord } from '../types'

const locations = [
  { postcode: 'E1 6RF',   city: 'London',       lat: 51.5136, lng: -0.0744 },
  { postcode: 'SW1A 1AA', city: 'London',       lat: 51.5014, lng: -0.1419 },
  { postcode: 'N1 9GU',   city: 'London',       lat: 51.5361, lng: -0.1052 },
  { postcode: 'SE1 7PB',  city: 'London',       lat: 51.5032, lng: -0.0921 },
  { postcode: 'W1A 1AA',  city: 'London',       lat: 51.5194, lng: -0.1438 },
  { postcode: 'M1 1AE',   city: 'Manchester',   lat: 53.4808, lng: -2.2426 },
  { postcode: 'M60 2LA',  city: 'Manchester',   lat: 53.4780, lng: -2.2440 },
  { postcode: 'B1 1BB',   city: 'Birmingham',   lat: 52.4862, lng: -1.8904 },
  { postcode: 'B9 4AA',   city: 'Birmingham',   lat: 52.4830, lng: -1.8540 },
  { postcode: 'LS1 1BA',  city: 'Leeds',        lat: 53.7997, lng: -1.5492 },
  { postcode: 'L1 1AA',   city: 'Liverpool',    lat: 53.4084, lng: -2.9916 },
  { postcode: 'G1 1AA',   city: 'Glasgow',      lat: 55.8617, lng: -4.2583 },
  { postcode: 'EH1 1BB',  city: 'Edinburgh',    lat: 55.9533, lng: -3.1883 },
  { postcode: 'CF10 1AA', city: 'Cardiff',      lat: 51.4816, lng: -3.1791 },
  { postcode: 'BS1 1AA',  city: 'Bristol',      lat: 51.4545, lng: -2.5879 },
  { postcode: 'NE1 1AA',  city: 'Newcastle',    lat: 54.9783, lng: -1.6178 },
  { postcode: 'S1 1AA',   city: 'Sheffield',    lat: 53.3811, lng: -1.4701 },
  { postcode: 'NG1 1AA',  city: 'Nottingham',   lat: 52.9548, lng: -1.1581 },
  { postcode: 'OX1 1AA',  city: 'Oxford',       lat: 51.7520, lng: -1.2577 },
  { postcode: 'CB1 1AA',  city: 'Cambridge',    lat: 52.2053, lng:  0.1218 },
]

const categories: Record<string, string[]> = {
  'Drugs':             ['Cannabis', 'Cocaine', 'Heroin', 'MDMA', 'Amphetamine', 'Ketamine'],
  'Weapons':           ['Knife', 'Firearm', 'Ammunition', 'Baton', 'Crossbow', 'Taser'],
  'Counterfeit Goods': ['Currency', 'Designer Clothing', 'Electronics', 'Travel Documents'],
  'Tobacco':           ['Cigarettes', 'Rolling Tobacco', 'Vapes', 'Hookah Products'],
  'Alcohol':           ['Spirits', 'Beer', 'Wine', 'Vodka'],
}

function rnd(arr: unknown[]) { return arr[Math.floor(Math.random() * arr.length)] }
function rndInt(min: number, max: number) { return Math.floor(Math.random() * (max - min + 1)) + min }

function generateDate(startYear = 2022, endYear = 2024): string {
  const start = new Date(startYear, 0, 1).getTime()
  const end   = new Date(endYear, 11, 31).getTime()
  return new Date(start + Math.random() * (end - start)).toISOString().split('T')[0]
}

export function generateMockData(count = 80): SeizureRecord[] {
  const records: SeizureRecord[] = []
  const catKeys = Object.keys(categories)

  for (let i = 0; i < count; i++) {
    const loc      = rnd(locations) as (typeof locations)[0]
    const catKey   = rnd(catKeys) as string
    const subCats  = categories[catKey]
    const subCat   = rnd(subCats) as string

    records.push({
      id:          `mock-${i}`,
      date:        generateDate(),
      category:    catKey,
      subCategory: subCat,
      item:        subCat,
      quantity:    rndInt(1, 500),
      postcode:    loc.postcode,
      city:        loc.city,
      lat:         loc.lat,
      lng:         loc.lng,
    })
  }

  return records.sort((a, b) => a.date.localeCompare(b.date))
}
