/**
 * Backend configuration.
 * To connect a real backend, set VITE_API_BASE_URL in your .env file.
 * Without it, the app runs fully in-browser using imported files.
 */
export const config = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL as string | undefined,
  useBackend: !!import.meta.env.VITE_API_BASE_URL,
}
