import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import Papa from 'papaparse'
import type { SeizureRecord } from '../types'

export async function exportToPDF(elementId: string, filename = 'seizure-report.pdf') {
  const el = document.getElementById(elementId)
  if (!el) return

  const canvas  = await html2canvas(el, { scale: 2, useCORS: true, logging: false })
  const imgData = canvas.toDataURL('image/png')

  const pdf     = new jsPDF({ orientation: 'landscape', unit: 'px', format: 'a4' })
  const pdfW    = pdf.internal.pageSize.getWidth()
  const pdfH    = (canvas.height * pdfW) / canvas.width

  pdf.addImage(imgData, 'PNG', 0, 0, pdfW, pdfH)
  pdf.save(filename)
}

export function exportToCSV(records: SeizureRecord[], filename = 'seizure-data.csv') {
  const csv = Papa.unparse(records.map((r) => ({
    Date:         r.date,
    Category:     r.category,
    'Sub-Category': r.subCategory,
    Item:         r.item,
    Quantity:     r.quantity,
    Postcode:     r.postcode,
    City:         r.city,
  })))

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url  = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href  = url
  link.setAttribute('download', filename)
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}
