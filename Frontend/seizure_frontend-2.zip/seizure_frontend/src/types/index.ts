export interface SeizureRecord {
  id: string
  date: string           // ISO date string YYYY-MM-DD
  category: string
  subCategory: string
  item: string
  quantity: number
  postcode: string
  city: string
  lat?: number
  lng?: number
  [key: string]: unknown // allow extra columns from import
}

export interface FilterState {
  datePreset: 'all' | 'monthly' | 'quarterly' | 'yearly' | 'custom'
  selectedYear: string
  selectedMonth: string
  selectedQuarter: string
  dateStart: string
  dateEnd: string
  categories: string[]
  subCategories: string[]
  postcode: string
  city: string
  keyword: string
}

export interface ColumnMapping {
  date: string
  category: string
  subCategory: string
  item: string
  quantity: string
  postcode: string
  city: string
}

export interface TopTenEntry {
  name: string
  value: number
}

export interface HeatPoint {
  postcode: string
  city: string
  lat: number
  lng: number
  count: number
}

export type ActivePage = 'dashboard' | 'heatmap' | 'data' | 'import'
