import { Search } from 'lucide-react'
import { useStore } from './store/useStore'
import Layout from './components/Layout/Layout'
import DashboardPage from './pages/DashboardPage'
import HeatmapPage from './pages/HeatmapPage'
import DataPage from './pages/DataPage'
import ImportPage from './pages/ImportPage'

export default function App() {
  const { activePage, filters, setFilter } = useStore()


  const PAGE_MAP = {
    dashboard: <DashboardPage />,
    heatmap:   <HeatmapPage />,
    data:      <DataPage />,
    import:    <ImportPage />,
  }

  return (
    <Layout>
      {/* Global keyword search bar */}
      <div
        className="flex items-center gap-3 px-6 border-b shrink-0"
        style={{ height: 56, background: '#fff', borderColor: '#e2e8f0' }}
      >
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <Search size={15} className="text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Search across all data…"
            value={filters.keyword}
            onChange={(e) => setFilter('keyword', e.target.value)}
            className="flex-1 text-sm text-slate-700 bg-transparent outline-none placeholder-slate-300"
          />
          {filters.keyword && (
            <button
              onClick={() => setFilter('keyword', '')}
              className="text-xs text-slate-400 hover:text-slate-600 transition-colors"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Active page */}
      {PAGE_MAP[activePage]}
    </Layout>
  )
}
