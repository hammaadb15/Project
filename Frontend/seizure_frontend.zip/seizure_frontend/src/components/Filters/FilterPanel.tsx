import { useState } from 'react'
import { ChevronDown, ChevronUp, RotateCcw } from 'lucide-react'
import { useStore } from '../../store/useStore'
import { getUniqueValues } from '../../utils/dataTransform'
import type { FilterState } from '../../types'

const DATE_PRESETS: { value: FilterState['datePreset']; label: string }[] = [
  { value: 'all',       label: 'All Time' },
  { value: 'monthly',   label: 'This Month' },
  { value: 'quarterly', label: 'This Quarter' },
  { value: 'yearly',    label: 'This Year' },
  { value: 'custom',    label: 'Custom Range' },
]

export default function FilterPanel() {
  const { records, filters, setFilter, resetFilters } = useStore()
  const [open, setOpen] = useState(true)

  const allCategories   = getUniqueValues(records, 'category')
  const allSubCats      = filters.categories.length > 0
    ? getUniqueValues(
        records.filter((r) => filters.categories.includes(r.category)),
        'subCategory'
      )
    : getUniqueValues(records, 'subCategory')

  function toggleMulti(
    key: 'categories' | 'subCategories',
    value: string
  ) {
    const current = filters[key]
    const next    = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value]
    setFilter(key, next)
    // Reset sub-cats when category changes
    if (key === 'categories') setFilter('subCategories', [])
  }

  return (
    <div
      className="border-b"
      style={{ background: '#ffffff', borderColor: '#e2e8f0' }}
    >
      {/* Toggle bar */}
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between px-6 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
      >
        <span>Filters</span>
        <span className="flex items-center gap-2 text-slate-400">
          {open ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </span>
      </button>

      {open && (
        <div className="px-6 pb-4 grid grid-cols-2 gap-x-6 gap-y-4 md:grid-cols-3 lg:grid-cols-5">

          {/* Date preset */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Date Range
            </label>
            <select
              className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none focus:ring-1"
              style={{ borderColor: '#e2e8f0' }}
              value={filters.datePreset}
              onChange={(e) =>
                setFilter('datePreset', e.target.value as FilterState['datePreset'])
              }
            >
              {DATE_PRESETS.map((p) => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </select>
            {filters.datePreset === 'custom' && (
              <div className="flex flex-col gap-1 mt-1">
                <input
                  type="date"
                  value={filters.dateStart}
                  onChange={(e) => setFilter('dateStart', e.target.value)}
                  className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
                  style={{ borderColor: '#e2e8f0' }}
                />
                <input
                  type="date"
                  value={filters.dateEnd}
                  onChange={(e) => setFilter('dateEnd', e.target.value)}
                  className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
                  style={{ borderColor: '#e2e8f0' }}
                />
              </div>
            )}
          </div>

          {/* Category */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Category
            </label>
            <div className="flex flex-col gap-1 max-h-32 overflow-y-auto">
              {allCategories.map((cat) => (
                <label key={cat} className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.categories.includes(cat)}
                    onChange={() => toggleMulti('categories', cat)}
                    className="rounded"
                    style={{ accentColor: '#2563eb' }}
                  />
                  {cat}
                </label>
              ))}
            </div>
          </div>

          {/* Sub-category */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Sub-Category
            </label>
            <div className="flex flex-col gap-1 max-h-32 overflow-y-auto">
              {allSubCats.map((sc) => (
                <label key={sc} className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.subCategories.includes(sc)}
                    onChange={() => toggleMulti('subCategories', sc)}
                    className="rounded"
                    style={{ accentColor: '#2563eb' }}
                  />
                  {sc}
                </label>
              ))}
            </div>
          </div>

          {/* Location */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Location
            </label>
            <input
              type="text"
              placeholder="Postcode"
              value={filters.postcode}
              onChange={(e) => setFilter('postcode', e.target.value)}
              className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
              style={{ borderColor: '#e2e8f0' }}
            />
            <input
              type="text"
              placeholder="City"
              value={filters.city}
              onChange={(e) => setFilter('city', e.target.value)}
              className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
              style={{ borderColor: '#e2e8f0' }}
            />
          </div>

          {/* Reset */}
          <div className="flex flex-col justify-end gap-2">
            <button
              onClick={resetFilters}
              className="flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium border transition-colors"
              style={{ borderColor: '#e2e8f0', color: '#64748b' }}
            >
              <RotateCcw size={14} /> Reset Filters
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
