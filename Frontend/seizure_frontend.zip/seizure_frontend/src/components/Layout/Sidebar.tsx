import { LayoutDashboard, Map, Table2, Upload, Menu, X } from 'lucide-react'
import { useState } from 'react'
import { useStore } from '../../store/useStore'
import type { ActivePage } from '../../types'

const NAV_ITEMS: { id: ActivePage; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard',  icon: <LayoutDashboard size={18} /> },
  { id: 'heatmap',   label: 'Heat Map',   icon: <Map size={18} /> },
  { id: 'data',      label: 'Data Table', icon: <Table2 size={18} /> },
  { id: 'import',    label: 'Import Data',icon: <Upload size={18} /> },
]

export default function Sidebar() {
  const { activePage, setActivePage } = useStore()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside
      className="flex flex-col shrink-0 transition-all duration-200"
      style={{
        width: collapsed ? 56 : 220,
        background: '#0f172a',
        minHeight: '100vh',
      }}
    >
      {/* Brand */}
      <div
        className="flex items-center gap-3 px-4 border-b border-white/10"
        style={{ height: 56 }}
      >
        {!collapsed && (
          <span className="text-white font-semibold text-sm leading-tight truncate">
            Seizure Data<br />
            <span style={{ color: '#60a5fa' }}>Visualisation</span>
          </span>
        )}
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="ml-auto text-slate-400 hover:text-white transition-colors"
          aria-label="Toggle sidebar"
        >
          {collapsed ? <Menu size={18} /> : <X size={18} />}
        </button>
      </div>

      {/* Nav */}
      <nav className="flex flex-col gap-1 p-2 flex-1">
        {NAV_ITEMS.map((item) => {
          const active = activePage === item.id
          return (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id)}
              title={collapsed ? item.label : undefined}
              className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors text-left w-full"
              style={{
                background: active ? '#1e40af' : 'transparent',
                color:      active ? '#ffffff' : '#94a3b8',
              }}
              onMouseEnter={(e) => {
                if (!active) (e.currentTarget as HTMLButtonElement).style.background = '#1e293b'
                if (!active) (e.currentTarget as HTMLButtonElement).style.color = '#e2e8f0'
              }}
              onMouseLeave={(e) => {
                if (!active) (e.currentTarget as HTMLButtonElement).style.background = 'transparent'
                if (!active) (e.currentTarget as HTMLButtonElement).style.color = '#94a3b8'
              }}
            >
              <span className="shrink-0">{item.icon}</span>
              {!collapsed && <span className="truncate">{item.label}</span>}
            </button>
          )
        })}
      </nav>

      {/* Footer */}
      {!collapsed && (
        <div className="px-4 py-3 border-t border-white/10">
          <p className="text-xs text-slate-500">v1.0.0</p>
        </div>
      )}
    </aside>
  )
}
