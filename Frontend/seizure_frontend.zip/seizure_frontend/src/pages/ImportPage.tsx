import { useStore } from '../store/useStore'
import FileImport from '../components/Import/FileImport'

export default function ImportPage() {
  const { records } = useStore()

  return (
    <div className="flex flex-col flex-1">
      <div
        className="flex items-center justify-between px-6 py-4 border-b"
        style={{ background: '#fff', borderColor: '#e2e8f0' }}
      >
        <div>
          <h1 className="text-lg font-semibold text-slate-800">Import Data</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Upload a CSV or Excel file to populate the visualisations
          </p>
        </div>
        <span className="text-xs text-slate-400">
          {records.length.toLocaleString()} records loaded
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-2xl mx-auto">
          <FileImport />

          {/* Instructions */}
          <div
            className="mt-8 rounded-xl border p-5"
            style={{ borderColor: '#e2e8f0', background: '#f8fafc' }}
          >
            <h3 className="text-sm font-semibold text-slate-700 mb-3">
              Expected Data Format
            </h3>
            <p className="text-sm text-slate-500 mb-3">
              Your file should contain the following columns (column names are flexible — you will map them in the next step):
            </p>
            <div className="rounded-lg overflow-hidden border border-slate-200">
              <table className="w-full text-xs">
                <thead>
                  <tr style={{ background: '#f1f5f9' }}>
                    <th className="px-3 py-2 text-left font-semibold text-slate-600">Field</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-600">Description</th>
                    <th className="px-3 py-2 text-left font-semibold text-slate-600">Example</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['Date',         'Seizure date',             '2024-03-15'],
                    ['Category',     'Main seizure category',    'Drugs'],
                    ['Sub-Category', 'Specific sub-type',        'Cannabis'],
                    ['Item',         'Item description',         'Cannabis resin'],
                    ['Quantity',     'Numeric quantity',         '250'],
                    ['Postcode',     'UK postcode',              'M1 1AE'],
                    ['City',         'City or town name',        'Manchester'],
                  ].map(([field, desc, ex], i) => (
                    <tr key={field} style={{ background: i % 2 === 0 ? '#fff' : '#f8fafc' }}>
                      <td className="px-3 py-2 font-medium text-slate-700">{field}</td>
                      <td className="px-3 py-2 text-slate-500">{desc}</td>
                      <td className="px-3 py-2 text-slate-400 font-mono">{ex}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-slate-400 mt-3">
              * The app will auto-detect column mappings where possible.
              Additional columns in your file are preserved and searchable.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
