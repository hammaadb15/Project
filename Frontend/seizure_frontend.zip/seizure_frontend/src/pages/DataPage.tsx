import { useMemo } from 'react'
import { FileDown, FileText } from 'lucide-react'
import { useStore } from '../store/useStore'
import { applyFilters } from '../utils/dataTransform'
import FilterPanel from '../components/Filters/FilterPanel'
import DataTable from '../components/Table/DataTable'
import { exportToPDF, exportToCSV } from '../utils/exportUtils'

export default function DataPage() {
  const { records, filters } = useStore()
  const filtered = useMemo(() => applyFilters(records, filters), [records, filters])

  return (
    <div className="flex flex-col flex-1">
      <div
        className="flex items-center justify-between px-6 py-4 border-b"
        style={{ background: '#fff', borderColor: '#e2e8f0' }}
      >
        <div>
          <h1 className="text-lg font-semibold text-slate-800">Data Table</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {filtered.length.toLocaleString()} records
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => exportToCSV(filtered)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-medium transition-colors"
            style={{ borderColor: '#e2e8f0', color: '#64748b' }}
          >
            <FileText size={14} /> Export CSV
          </button>
          <button
            onClick={() => exportToPDF('data-content')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium text-white"
            style={{ background: '#2563eb' }}
          >
            <FileDown size={14} /> Export PDF
          </button>
        </div>
      </div>

      <FilterPanel />

      <div id="data-content" className="flex-1 overflow-y-auto p-6">
        <DataTable records={filtered} />
      </div>
    </div>
  )
}
