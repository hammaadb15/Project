import { useState, useRef, useCallback } from 'react'
import { Upload, FileText, CheckCircle, AlertCircle, X } from 'lucide-react'
import Papa from 'papaparse'
import * as XLSX from 'xlsx'
import { useStore } from '../../store/useStore'
import type { ColumnMapping } from '../../types'

const REQUIRED_COLUMNS: (keyof ColumnMapping)[] = [
  'date', 'category', 'subCategory', 'item', 'quantity', 'postcode', 'city',
]

const COLUMN_LABELS: Record<keyof ColumnMapping, string> = {
  date:        'Date',
  category:    'Category',
  subCategory: 'Commodity',
  item:        'Description',
  quantity:    'Weight/Quantity',
  postcode:    'Postcode',
  city:        'City',
}

export default function FileImport() {
  const { setRecords, setLoading } = useStore()

  const [dragging,   setDragging]   = useState(false)
  const [sourceFile, setSourceFile] = useState<File | null>(null)
  const [headers,    setHeaders]    = useState<string[]>([])
  const [rawRows,    setRawRows]    = useState<Record<string, string>[]>([])
  const [mapping,    setMapping]    = useState<Partial<ColumnMapping>>({})
  const [fileName,   setFileName]   = useState('')
  const [status,     setStatus]     = useState<'idle' | 'mapping' | 'done' | 'error'>('idle')
  const [message,    setMessage]    = useState('')

  const inputRef = useRef<HTMLInputElement>(null)

  function parseFile(file: File) {
    setFileName(file.name)
    setSourceFile(file)
    setStatus('idle')
    setMessage('')

    const ext = file.name.split('.').pop()?.toLowerCase()

    if (ext === 'csv') {
      Papa.parse<Record<string, string>>(file, {
        header:       true,
        skipEmptyLines: true,
        complete: (results) => {
          const h = results.meta.fields ?? []
          setHeaders(h)
          setRawRows(results.data)
          autoMap(h)
          setStatus('mapping')
        },
        error: () => {
          setStatus('error')
          setMessage('Failed to parse CSV file.')
        },
      })
    } else if (ext === 'xls' || ext === 'xlsx') {
      const reader = new FileReader()
      reader.onload = (e) => {
        const data     = new Uint8Array(e.target!.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array' })
        const sheetName = workbook.SheetNames.includes('Data') ? 'Data' : workbook.SheetNames[0]
        const sheet    = workbook.Sheets[sheetName]
        const json     = XLSX.utils.sheet_to_json<Record<string, string>>(sheet, { defval: '' })
        const h        = json.length > 0 ? Object.keys(json[0]) : []
        setHeaders(h)
        setRawRows(json)
        autoMap(h)
        setStatus('mapping')
      }
      reader.readAsArrayBuffer(file)
    } else {
      setStatus('error')
      setMessage('Unsupported file type. Please upload a CSV or XLS/XLSX file.')
    }
  }

  function autoMap(h: string[]) {
    const lh = h.map((x) => x.toLowerCase())
    const guesses: Partial<ColumnMapping> = {}
    const try_ = (key: keyof ColumnMapping, candidates: string[]) => {
      const found = candidates.find((c) => lh.some((lhItem) => lhItem.includes(c)))
      if (found) {
        const idx = lh.findIndex((lhItem) => lhItem.includes(found))
        if (idx !== -1) guesses[key] = h[idx]
      }
    }
    try_('date',        ['date', 'datetime', 'seizure_date', 'occurrence', 'seizure'])
    try_('category',    ['category', 'cat', 'type'])
    try_('subCategory', ['subcategory', 'sub_category', 'sub', 'subcat', 'commodity'])
    try_('item',        ['description', 'item', 'desc', 'name', 'product'])
    try_('quantity',    ['quantity', 'weight', 'qty', 'amount', 'count', 'number'])
    try_('postcode',    ['postcode', 'post_code', 'postal', 'zip'])
    try_('city',        ['city', 'town', 'location', 'address'])
    setMapping(guesses)
  }

  async function applyMapping() {
    const missing = REQUIRED_COLUMNS.filter((c) => !mapping[c])
    if (missing.length > 0) {
      setStatus('error')
      setMessage(`Please map the following columns: ${missing.map((m) => COLUMN_LABELS[m]).join(', ')}`)
      return
    }

    if (!sourceFile) return

    setLoading(true)

    try {
      const formData = new FormData()
      formData.append('file', sourceFile)
      formData.append('mapping_json', JSON.stringify(mapping))

      const baseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'
      const response = await fetch(`${baseUrl}/api/import`, {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.status} ${await response.text()}`)
      }

      const data = await response.json()
      setRecords(data.records)
      setStatus('done')
      setMessage(`${data.records.length} records imported successfully.`)
    } catch (err: any) {
      setStatus('error')
      setMessage(err.message || 'Failed to process file with backend.')
    } finally {
      setLoading(false)
    }
  }

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) parseFile(file)
  }, [])

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) parseFile(file)
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        className="flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed cursor-pointer transition-colors py-14"
        style={{
          borderColor: dragging ? '#2563eb' : '#cbd5e1',
          background:  dragging ? '#eff6ff' : '#f8fafc',
        }}
      >
        <Upload size={36} style={{ color: dragging ? '#2563eb' : '#94a3b8' }} />
        <div className="text-center">
          <p className="text-sm font-medium text-slate-700">
            Drop your file here, or click to browse
          </p>
          <p className="text-xs text-slate-400 mt-1">Supports CSV, XLS, XLSX</p>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,.xls,.xlsx"
          className="hidden"
          onChange={handleFile}
        />
      </div>

      {/* File name */}
      {fileName && (
        <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-50 border border-slate-200">
          <FileText size={16} className="text-slate-500" />
          <span className="text-sm text-slate-700 truncate">{fileName}</span>
          <button
            className="ml-auto text-slate-400 hover:text-slate-600"
            onClick={() => { setFileName(''); setSourceFile(null); setStatus('idle'); setHeaders([]); setRawRows([]) }}
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Status message */}
      {message && (
        <div
          className="flex items-center gap-2 px-4 py-3 rounded-lg text-sm"
          style={{
            background: status === 'done'  ? '#f0fdf4' : status === 'error' ? '#fef2f2' : '#eff6ff',
            color:      status === 'done'  ? '#15803d' : status === 'error' ? '#dc2626' : '#1d4ed8',
            border:     `1px solid ${status === 'done' ? '#bbf7d0' : status === 'error' ? '#fecaca' : '#bfdbfe'}`,
          }}
        >
          {status === 'done'  && <CheckCircle size={16} />}
          {status === 'error' && <AlertCircle size={16} />}
          {message}
        </div>
      )}

      {/* Column mapping */}
      {status === 'mapping' && headers.length > 0 && (
        <div className="rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 bg-slate-50">
            <h3 className="text-sm font-semibold text-slate-700">Map Columns</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Match your file's column headers to the required fields.
            </p>
          </div>
          <div className="p-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {REQUIRED_COLUMNS.map((col) => (
              <div key={col} className="flex flex-col gap-1">
                <label className="text-xs font-medium text-slate-600">
                  {COLUMN_LABELS[col]}
                  <span className="text-red-400 ml-0.5">*</span>
                </label>
                <select
                  className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
                  style={{ borderColor: '#e2e8f0' }}
                  value={mapping[col] ?? ''}
                  onChange={(e) =>
                    setMapping((prev) => ({ ...prev, [col]: e.target.value || undefined }))
                  }
                >
                  <option value="">— Select column —</option>
                  {headers.map((h) => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>
            ))}
          </div>
          <div className="px-5 pb-5">
            <button
              onClick={applyMapping}
              className="px-5 py-2 rounded-lg text-sm font-semibold text-white transition-colors"
              style={{ background: '#2563eb' }}
            >
              Import {rawRows.length} Records
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
