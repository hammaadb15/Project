import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell,
} from 'recharts'
import type { TopTenEntry } from '../../types'

interface Props {
  data: TopTenEntry[]
  title?: string
}

const COLORS = [
  '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd',
  '#bfdbfe', '#1d4ed8', '#1e40af', '#1e3a8a',
  '#dbeafe', '#eff6ff',
]

export default function TopTenChart({ data, title = 'Top 10 Most Seized Items' }: Props) {
  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-sm text-slate-400">
        No data to display
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-3">
      {title && (
        <h3 className="text-sm font-semibold text-slate-700">{title}</h3>
      )}
      <ResponsiveContainer width="100%" height={320}>
        <BarChart
          data={data}
          layout="vertical"
          margin={{ top: 0, right: 20, left: 10, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
          <XAxis
            type="number"
            tick={{ fontSize: 11, fill: '#94a3b8' }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            type="category"
            dataKey="name"
            width={120}
            tick={{ fontSize: 11, fill: '#64748b' }}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip
            contentStyle={{
              border:     '1px solid #e2e8f0',
              borderRadius: '8px',
              fontSize:   12,
              boxShadow:  '0 4px 6px -1px rgb(0 0 0 / 0.1)',
            }}
            formatter={(value) => [Number(value).toLocaleString(), 'Quantity']}
          />
          <Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={28}>
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
