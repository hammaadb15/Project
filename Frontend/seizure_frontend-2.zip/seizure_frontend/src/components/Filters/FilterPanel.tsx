import { useState, useMemo, useEffect } from 'react'
import { ChevronDown, ChevronUp, RotateCcw } from 'lucide-react'
import { useStore } from '../../store/useStore'
import { getUniqueValues } from '../../utils/dataTransform'
import type { FilterState } from '../../types'

const DATE_PRESETS: { value: FilterState['datePreset']; label: string }[] = [
  { value: 'all',       label: 'All Time' },
  { value: 'yearly',    label: 'Yearly' },
  { value: 'monthly',   label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'custom',    label: 'Custom Range' },
]

export default function FilterPanel() {
  const { records, filters, setFilter, resetFilters } = useStore()
  const [open, setOpen] = useState(true)

  const allCategories   = getUniqueValues(records, 'category')
  const allSubCats      = filters.categories.length > 0
    ? getUniqueValues(
        records.filter((r) => filters.categories.includes(r.category)),
        'subCategory'
      )
    : getUniqueValues(records, 'subCategory')

  const allYears = useMemo(() => {
    const years = new Set<string>()
    records.forEach(r => {
      if (r.date) years.add(r.date.split('-')[0])
    })
    const arr = Array.from(years).sort().reverse()
    if (arr.length === 0) arr.push(new Date().getFullYear().toString())
    return arr
  }, [records])

  useEffect(() => {
    if (records.length > 0 && !allYears.includes(filters.selectedYear)) {
      setFilter('selectedYear', allYears[0])
    }
  }, [allYears, filters.selectedYear, records.length, setFilter])

  function toggleMulti(
    key: 'categories' | 'subCategories',
    value: string
  ) {
    const current = filters[key]
    const next    = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value]
    setFilter(key, next)
    // Reset sub-cats when category changes
    if (key === 'categories') setFilter('subCategories', [])
  }

  return (
    <div
      className="border-b"
      style={{ background: '#ffffff', borderColor: '#e2e8f0' }}
    >
      {/* Toggle bar */}
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between px-6 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
      >
        <span>Filters</span>
        <span className="flex items-center gap-2 text-slate-400">
          {open ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </span>
      </button>

      {open && (
        <div className="px-6 pb-4 grid grid-cols-2 gap-x-6 gap-y-4 md:grid-cols-3 lg:grid-cols-5">

          {/* Date preset */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Date Range
            </label>
            <select
              className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none focus:ring-1"
              style={{ borderColor: '#e2e8f0' }}
              value={filters.datePreset}
              onChange={(e) =>
                setFilter('datePreset', e.target.value as FilterState['datePreset'])
              }
            >
              {DATE_PRESETS.map((p) => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </select>
            
            {(filters.datePreset === 'yearly' || filters.datePreset === 'monthly' || filters.datePreset === 'quarterly') && (
              <select
                className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none mt-1"
                style={{ borderColor: '#e2e8f0' }}
                value={filters.selectedYear}
                onChange={(e) => setFilter('selectedYear', e.target.value)}
              >
                {allYears.map((yr) => (
                  <option key={yr} value={yr}>{yr}</option>
                ))}
              </select>
            )}

            {filters.datePreset === 'monthly' && (
              <select
                className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none mt-1"
                style={{ borderColor: '#e2e8f0' }}
                value={filters.selectedMonth}
                onChange={(e) => setFilter('selectedMonth', e.target.value)}
              >
                {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((name, idx) => (
                  <option key={idx} value={idx}>{name}</option>
                ))}
              </select>
            )}

            {filters.datePreset === 'quarterly' && (
              <select
                className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none mt-1"
                style={{ borderColor: '#e2e8f0' }}
                value={filters.selectedQuarter}
                onChange={(e) => setFilter('selectedQuarter', e.target.value)}
              >
                <option value="1">Q1 (Jan-Mar)</option>
                <option value="2">Q2 (Apr-Jun)</option>
                <option value="3">Q3 (Jul-Sep)</option>
                <option value="4">Q4 (Oct-Dec)</option>
              </select>
            )}

            {filters.datePreset === 'custom' && (
              <div className="flex flex-col gap-1 mt-1">
                <input
                  type="date"
                  value={filters.dateStart}
                  onChange={(e) => setFilter('dateStart', e.target.value)}
                  className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
                  style={{ borderColor: '#e2e8f0' }}
                />
                <input
                  type="date"
                  value={filters.dateEnd}
                  onChange={(e) => setFilter('dateEnd', e.target.value)}
                  className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
                  style={{ borderColor: '#e2e8f0' }}
                />
              </div>
            )}
          </div>

          {/* Category */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Category
            </label>
            <div className="flex flex-col gap-1 max-h-32 overflow-y-auto">
              {allCategories.map((cat) => (
                <label key={cat} className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.categories.includes(cat)}
                    onChange={() => toggleMulti('categories', cat)}
                    className="rounded"
                    style={{ accentColor: '#2563eb' }}
                  />
                  {cat}
                </label>
              ))}
            </div>
          </div>

          {/* Commodity */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Commodity
            </label>
            <div className="flex flex-col gap-1 max-h-32 overflow-y-auto">
              {allSubCats.map((sc) => (
                <label key={sc} className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={filters.subCategories.includes(sc)}
                    onChange={() => toggleMulti('subCategories', sc)}
                    className="rounded"
                    style={{ accentColor: '#2563eb' }}
                  />
                  {sc}
                </label>
              ))}
            </div>
          </div>

          {/* Location */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium text-slate-500 uppercase tracking-wide">
              Location
            </label>
            <input
              type="text"
              placeholder="Postcode"
              value={filters.postcode}
              onChange={(e) => setFilter('postcode', e.target.value)}
              className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
              style={{ borderColor: '#e2e8f0' }}
            />
            <input
              type="text"
              placeholder="City"
              value={filters.city}
              onChange={(e) => setFilter('city', e.target.value)}
              className="border rounded-md px-2 py-1.5 text-sm text-slate-700 focus:outline-none"
              style={{ borderColor: '#e2e8f0' }}
            />
          </div>

          {/* Reset */}
          <div className="flex flex-col justify-end gap-2">
            <button
              onClick={resetFilters}
              className="flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium border transition-colors"
              style={{ borderColor: '#e2e8f0', color: '#64748b' }}
            >
              <RotateCcw size={14} /> Reset Filters
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
