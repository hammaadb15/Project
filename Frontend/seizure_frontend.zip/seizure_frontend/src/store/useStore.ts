import { create } from 'zustand'
import type { SeizureRecord, FilterState, ActivePage } from '../types'
import { generateMockData } from '../data/mockData'

const DEFAULT_FILTERS: FilterState = {
  datePreset:    'all',
  dateStart:     '',
  dateEnd:       '',
  categories:    [],
  subCategories: [],
  postcode:      '',
  city:          '',
  keyword:       '',
}

interface AppStore {
  records:    SeizureRecord[]
  filters:    FilterState
  activePage: ActivePage
  isLoading:  boolean

  setRecords:  (records: SeizureRecord[]) => void
  setFilter:   <K extends keyof FilterState>(key: K, value: FilterState[K]) => void
  resetFilters: () => void
  setActivePage: (page: ActivePage) => void
  setLoading:  (loading: boolean) => void
}

export const useStore = create<AppStore>((set) => ({
  records:    generateMockData(80),
  filters:    DEFAULT_FILTERS,
  activePage: 'dashboard',
  isLoading:  false,

  setRecords:    (records) => set({ records }),
  setFilter:     (key, value) =>
    set((state) => ({ filters: { ...state.filters, [key]: value } })),
  resetFilters:  () => set({ filters: DEFAULT_FILTERS }),
  setActivePage: (page) => set({ activePage: page }),
  setLoading:    (loading) => set({ isLoading: loading }),
}))
