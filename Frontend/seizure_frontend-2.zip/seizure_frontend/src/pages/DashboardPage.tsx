import { useMemo } from 'react'
import { FileDown, FileText } from 'lucide-react'
import { useStore } from '../store/useStore'
import { applyFilters, getTopTen, getCategoryBreakdown } from '../utils/dataTransform'
import FilterPanel from '../components/Filters/FilterPanel'
import TopTenChart from '../components/Charts/TopTenChart'
import CategoryBreakdown from '../components/Charts/CategoryBreakdown'
import { exportToPDF, exportToCSV } from '../utils/exportUtils'

export default function DashboardPage() {
  const { records, filters } = useStore()
  const filtered = useMemo(() => applyFilters(records, filters), [records, filters])

  const topTen    = useMemo(() => getTopTen(filtered),            [filtered])
  const catBreak  = useMemo(() => getCategoryBreakdown(filtered), [filtered])

  const totalQty      = filtered.reduce((s, r) => s + r.quantity, 0)
  const uniqueItems   = new Set(filtered.map((r) => r.item)).size
  const uniqueLocs    = new Set(filtered.map((r) => r.postcode)).size
  const uniqueCats    = new Set(filtered.map((r) => r.category)).size

  const kpis = [
    { label: 'Total Records',       value: filtered.length.toLocaleString() },
    { label: 'Total Weight/Qty',    value: totalQty.toLocaleString() },
    { label: 'Unique Descriptions', value: uniqueItems.toLocaleString() },
    { label: 'Locations',           value: uniqueLocs.toLocaleString() },
    { label: 'Categories',          value: uniqueCats.toLocaleString() },
  ]

  return (
    <div className="flex flex-col flex-1">
      {/* Page header */}
      <div
        className="flex items-center justify-between px-6 py-4 border-b"
        style={{ background: '#fff', borderColor: '#e2e8f0' }}
      >
        <div>
          <h1 className="text-lg font-semibold text-slate-800">Dashboard</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {filtered.length.toLocaleString()} records visible
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => exportToCSV(filtered)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-medium transition-colors"
            style={{ borderColor: '#e2e8f0', color: '#64748b' }}
          >
            <FileText size={14} /> CSV
          </button>
          <button
            onClick={() => exportToPDF('dashboard-content')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium text-white transition-colors"
            style={{ background: '#2563eb' }}
          >
            <FileDown size={14} /> PDF
          </button>
        </div>
      </div>

      <FilterPanel />

      {/* Scrollable content */}
      <div id="dashboard-content" className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
        {/* KPI cards */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {kpis.map((kpi) => (
            <div
              key={kpi.label}
              className="rounded-xl border p-4 bg-white"
              style={{ borderColor: '#e2e8f0' }}
            >
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wide">
                {kpi.label}
              </p>
              <p className="text-2xl font-bold text-slate-800 mt-1">{kpi.value}</p>
            </div>
          ))}
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Top 10 – takes 2/3 width */}
          <div
            className="lg:col-span-2 rounded-xl border bg-white p-5"
            style={{ borderColor: '#e2e8f0' }}
          >
            <TopTenChart data={topTen} />
          </div>

          {/* Category breakdown */}
          <div
            className="rounded-xl border bg-white p-5"
            style={{ borderColor: '#e2e8f0' }}
          >
            <h3 className="text-sm font-semibold text-slate-700 mb-3">
              By Category
            </h3>
            <CategoryBreakdown data={catBreak} />
          </div>
        </div>
      </div>
    </div>
  )
}
