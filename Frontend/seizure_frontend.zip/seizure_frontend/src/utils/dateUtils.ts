export function getPresetRange(
  preset: 'monthly' | 'quarterly' | 'yearly'
): { start: string; end: string } {
  const now   = new Date()
  const end   = now.toISOString().split('T')[0]
  let start: Date

  if (preset === 'monthly') {
    start = new Date(now.getFullYear(), now.getMonth(), 1)
  } else if (preset === 'quarterly') {
    const q = Math.floor(now.getMonth() / 3)
    start   = new Date(now.getFullYear(), q * 3, 1)
  } else {
    start   = new Date(now.getFullYear(), 0, 1)
  }

  return { start: start.toISOString().split('T')[0], end }
}

export function formatDate(iso: string): string {
  const [y, m, d] = iso.split('-')
  return `${d}/${m}/${y}`
}

export function formatMonthYear(iso: string): string {
  const date = new Date(iso)
  return date.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })
}
