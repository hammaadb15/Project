/**
 * Abstract data service interface.
 * Any backend (REST, GraphQL, local) must implement this contract.
 * Components only depend on this interface — never on transport details.
 */
import type { SeizureRecord } from '../types'

export interface DataService {
  fetchRecords(): Promise<SeizureRecord[]>
}

/**
 * HTTP backend service stub.
 * Set VITE_API_BASE_URL in .env to activate.
 * Replace the endpoints below to match your actual backend API.
 */
export class HttpDataService implements DataService {
  private baseUrl: string

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl
  }

  async fetchRecords(): Promise<SeizureRecord[]> {
    const response = await fetch(`${this.baseUrl}/api/seizures`)
    if (!response.ok) throw new Error(`API error: ${response.status}`)
    return response.json() as Promise<SeizureRecord[]>
  }
}
