import { useState, useMemo } from 'react'
import { ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react'
import { formatDate } from '../../utils/dateUtils'
import type { SeizureRecord } from '../../types'

interface Props {
  records: SeizureRecord[]
}

type SortDir = 'asc' | 'desc' | null

const PAGE_SIZES = [25, 50, 100]

const COLUMNS: { key: keyof SeizureRecord; label: string }[] = [
  { key: 'date',        label: 'Date' },
  { key: 'category',    label: 'Category' },
  { key: 'subCategory', label: 'Sub-Category' },
  { key: 'item',        label: 'Item' },
  { key: 'quantity',    label: 'Quantity' },
  { key: 'postcode',    label: 'Postcode' },
  { key: 'city',        label: 'City' },
]

export default function DataTable({ records }: Props) {
  const [sortKey, setSortKey]   = useState<keyof SeizureRecord>('date')
  const [sortDir, setSortDir]   = useState<SortDir>('desc')
  const [page,    setPage]      = useState(1)
  const [pageSize, setPageSize] = useState(25)

  function handleSort(key: keyof SeizureRecord) {
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : d === 'desc' ? null : 'asc'))
    } else {
      setSortKey(key)
      setSortDir('asc')
    }
    setPage(1)
  }

  const sorted = useMemo(() => {
    if (!sortDir) return records
    return [...records].sort((a, b) => {
      const av = a[sortKey] ?? ''
      const bv = b[sortKey] ?? ''
      const cmp = String(av).localeCompare(String(bv), undefined, { numeric: true })
      return sortDir === 'asc' ? cmp : -cmp
    })
  }, [records, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize))
  const paginated  = sorted.slice((page - 1) * pageSize, page * pageSize)

  function SortIcon({ col }: { col: keyof SeizureRecord }) {
    if (sortKey !== col || !sortDir) return <ChevronsUpDown size={12} className="text-slate-300" />
    return sortDir === 'asc'
      ? <ChevronUp   size={12} className="text-blue-500" />
      : <ChevronDown size={12} className="text-blue-500" />
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Table */}
      <div className="rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr style={{ background: '#f8fafc' }}>
                {COLUMNS.map((col) => (
                  <th
                    key={col.key}
                    onClick={() => handleSort(col.key)}
                    className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wide cursor-pointer select-none border-b border-slate-200 whitespace-nowrap"
                  >
                    <span className="flex items-center gap-1">
                      {col.label}
                      <SortIcon col={col.key} />
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={COLUMNS.length} className="text-center py-12 text-slate-400 text-sm">
                    No records match the current filters.
                  </td>
                </tr>
              ) : (
                paginated.map((row, i) => (
                  <tr
                    key={row.id}
                    style={{ background: i % 2 === 0 ? '#ffffff' : '#f8fafc' }}
                    className="hover:bg-blue-50 transition-colors"
                  >
                    <td className="px-4 py-2.5 text-slate-600 whitespace-nowrap">{formatDate(row.date)}</td>
                    <td className="px-4 py-2.5">
                      <span
                        className="px-2 py-0.5 rounded-full text-xs font-medium"
                        style={{ background: '#eff6ff', color: '#1d4ed8' }}
                      >
                        {row.category}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-slate-600">{row.subCategory}</td>
                    <td className="px-4 py-2.5 font-medium text-slate-700">{row.item}</td>
                    <td className="px-4 py-2.5 text-slate-700 text-right font-mono">
                      {row.quantity.toLocaleString()}
                    </td>
                    <td className="px-4 py-2.5 text-slate-500 font-mono text-xs">{row.postcode}</td>
                    <td className="px-4 py-2.5 text-slate-600">{row.city}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <span>Rows per page:</span>
          <select
            value={pageSize}
            onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1) }}
            className="border rounded px-2 py-1 text-sm text-slate-700"
            style={{ borderColor: '#e2e8f0' }}
          >
            {PAGE_SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <span className="ml-2">
            {sorted.length === 0
              ? '0 records'
              : `${(page - 1) * pageSize + 1}–${Math.min(page * pageSize, sorted.length)} of ${sorted.length.toLocaleString()}`}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage(1)}
            disabled={page === 1}
            className="px-2 py-1 rounded text-sm text-slate-500 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
          >
            «
          </button>
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-2 py-1 rounded text-sm text-slate-500 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
          >
            ‹
          </button>
          <span className="px-3 py-1 text-sm text-slate-700 font-medium">
            {page} / {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="px-2 py-1 rounded text-sm text-slate-500 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
          >
            ›
          </button>
          <button
            onClick={() => setPage(totalPages)}
            disabled={page === totalPages}
            className="px-2 py-1 rounded text-sm text-slate-500 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed"
          >
            »
          </button>
        </div>
      </div>
    </div>
  )
}
